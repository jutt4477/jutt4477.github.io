# Asifjutt4477 Website

A responsive personal website for Asifjutt4477.

## Files
- index.html — main website
- style.css — design and responsive layout
- script.js — smooth scrolling

## Before publishing
Replace the `#` social links in index.html with your real TikTok, YouTube, Facebook and Instagram URLs.
Replace `your@email.com` with your real email address.
